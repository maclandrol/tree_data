#!/bin/bash
seqconvert="$HOME/Documents/Projects/Programmation/Scripting/pyphylo/script/seqconvert.py"
for dos in `ls -d */ | grep 'ST*'`; do
  echo "===> Currently in $dos"
  mafft --auto "$dos"sequences.fst > "$dos"sequences.ali
  python "$seqconvert" $dos/sequences.ali fasta phylip $dos/sequences.phy
  phyml --input "$dos"sequences.phy -o 'tlr' -d 'aa'
done